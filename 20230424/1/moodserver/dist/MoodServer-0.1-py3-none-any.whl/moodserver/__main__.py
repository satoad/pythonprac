import asyncio
from .server import main

asyncio.run(main())
